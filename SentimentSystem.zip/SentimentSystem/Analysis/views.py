# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from .models import *
from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import json
import Analysis.models
from gensim.models.word2vec import Word2Vec
import numpy as np
import pandas as pd
import jieba
import pickle
from sklearn.externals import joblib
from sklearn.svm import SVC
# Create your views here.
#============================================== <<<< Model API >>>> ==============================
def buildWordVector(text,size,w2v):

    vec = np.zeros(size).reshape((1, size))
    count = 0.0

    for word in text:
        try:
            vec += w2v[word].reshape((1,size))
            count += 1
        except KeyError:
            continue
    if count != 0:
        vec /= count
    return  vec

def get_predict_vecs(words):
    n_dim = 300
    w2v = Word2Vec.load('G:\Desktop\Sentiment\svm_data\w2v_model/w2v_model_all.pkl')
    vecs=buildWordVector(words, n_dim, w2v)
    return vecs

#============================================== <<<< PAGE VIEWS >>>> ==============================
def index(request):
    context = {
        'sentiment': '200'
    }
    return render(request, 'index.html', context)


def test(request):
    if request.method == 'POST':
        content = request.POST.get('content')
        words = jieba.lcut(content)
        word_vecs = get_predict_vecs(words)
        clf = joblib.load('G:\Desktop\Sentiment\model\svm_model\svm_model_ori.pkl')
        result = clf.predict(word_vecs)
        print result
        if int(result[0]) == 1.:
            sentiment = 'positive'
            return HttpResponse(json.dumps(sentiment), content_type="application/json")
        else:
            sentiment = 'negative'
            return HttpResponse(json.dumps(sentiment), content_type="application/json")


    else:
       # content = request.POST.get('content')
       # return HttpResponse(json.dumps(content), content_type="application/json")
        return  render(request, 'index.html')


def analysis(request):
   # shop=Shop.objects.all()
    sql1='select count(*) from shop'
    sql2 = 'select count(*) from analysis'
    sql3='select distinct sentiment,count(sentiment) from analysis group by sentiment'

    try:
        result1=getDataFromSQL(sql1)
        result2 = getDataFromSQL(sql2)
        result3 = getDataFromSQL(sql3)


    except:
        pass
    context={
        'value1':result1[0][0],
        'value2':result2[0][0],
        'value4': result3[0][1],
        'value3': result3[1][1],

    }
    return  render(request, 'Analysis.html', context)

#============================================== <<<< Analysis SQL >>>> ==============================
def productSentiment(request):

      sql='select distinct good.good_name, sum( case when analysis.sentiment=1 then 1 else 0 end ) , sum( case when analysis.sentiment=0 then 1 else 0 end ) from good,analysis,trade where analysis.trade_id = trade.trade_id and trade.good_id=good.good_id   group by good_name '
      good={}
      try :
          result = getDataFromSQL(sql)
          good_name = [r[0] for r in result]
          pos =[int(r[1]) for r in result]
          neg =[-int(r[2]) for r in result]
          good['good_name'] = good_name
          good['postive'] = pos
          good['negative'] = neg
      except:
          pass
      return HttpResponse(json.dumps(good), content_type="application/json")

def getlevel(request):
    sql = 'select distinct user.user_level ,count(user.user_level)from analysis,user,trade where analysis.trade_id=trade.trade_id and trade.user_id=user.user_id group by user.user_level '
    level={}
    temp={}

    try:

        result =getDataFromSQL(sql)
        level_name=[r[0] for r in result]
        level_count=[r[1] for r in result]
        count = [{'name': 0, 'value': 0}]*len(level_count)
        for i in range(len(level_name)):
            count[i] = {'name':0,'value':0}

            count[i]['name'] = level_name[i]
            count[i]['value'] = level_count[i]




        level['level_name']=level_name
        level['level_count']=count
        #print level
    except:
        pass
    return HttpResponse(json.dumps(level), content_type="application/json")

def colored(request):
    sql="select distinct good.good_name ,sum( case when good.good_color='金色' then 1 else 0 end )as a,sum( case when good.good_color='黑色' then 1 else 0 end )as b,sum( case when good.good_color='亮黑色' then 1 else 0 end )as c,sum( case when good.good_color='红色' then 1 else 0 end )as d,sum( case when good.good_color='玫瑰金色' then 1 else 0 end )as e,sum( case when good.good_color='银色' then 1 else 0 end )as f,sum( case when good.good_color='深空灰' then 1 else 0 end )as g,sum( case when good.good_color='太空灰' then 1 else 0 end )as h from good,trade where good.good_id=trade.good_id  group by good.good_name"
    color={}
    try:

        result = getDataFromSQL(sql)
        name = [r[0] for r in result]
        gold = [int(r[1]) for r in result]
        black = [int(r[2]) for r in result]
        blacklight = [int(r[3]) for r in result]
        red = [int(r[4]) for r in result]
        flower = [int(r[5]) for r in result]
        sliver = [int(r[6]) for r in result]
        blacksky = [int(r[7]) for r in result]
        sky= [int(r[8]) for r in result]

        color['name'] = name
        color['gold'] = gold
        color['black'] = black
        color['blacklight'] = blacklight
        color['red'] = red
        color['flower'] = flower
        color['sliver'] = sliver
        color['balcksky'] = blacksky
        color['sky'] = sky

    except:
        pass
    return HttpResponse(json.dumps(color), content_type="application/json")
#============================================== <<<< Analysis dropdown >>>> ==============================
def getprodutlist(request):
    sql="select distinct good_name from good"
    goodname = {}
    try:
        result = getDataFromSQL(sql)
        result = [r[0] for r in result]
        for key in result:
            goodname[key] = key
    except Exception as e:
        print('geproductlist: ' + str(e))
        goodname['EN-US'] = 'EN-US'
    return JsonResponse(goodname)

def getshopname(request):
    sql="select distinct shop_name from shop"
    shopname = {}
    try:
        result = getDataFromSQL(sql)
        result = [r[0] for r in result]
        for key in result:
            shopname[key] = key
    except Exception as e:
        print('getshopname Erroor:' +str(e))
        shopname['EN-US'] = 'EN-US'
    return JsonResponse(shopname)

def userorder(request):
     shop_name=request.GET.get('shop')
     good_name=request.GET.get('product')
     print shop_name,good_name
     sql = "select DATE_FORMAT(time,'%%Y%%m') months ,sum(case when analysis.sentiment=1 then 1 else 0 end) pos,sum(case when analysis.sentiment=0 then 1 else 0 end) neg from comment,analysis,good,shop_good,shop where analysis.trade_id=comment.trade_id and comment.good_id=good.good_id and good.good_name='%s' and good.good_id=shop_good.good_id and shop_good.shop_id=shop.shop_id and shop.shop_name='%s' group by months"% (good_name,shop_name)
     source = {}
     resultadd = []
     try:
         result = getDataFromSQL(sql)

         result1 = [r[0] for r in result]
         result1.insert(0 , 'product')
         result2 =[int(r[1]) for r in result]
         result2.insert(0, 'postive')
         result3 =[int(r[2]) for r in result]
         result3.insert(0, 'negative')
         resultadd.append(result1)
         resultadd.append(result2)
         resultadd.append(result3)
         source['source']=resultadd

     except:
         pass
     return JsonResponse(source)