"""SentimentSystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from Analysis.views import index
from Analysis.views import test
from Analysis.views import *

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^index/$', index, name='home'),
    url(r'^index/test', test, name='test'),

   # url(r'^index/test', test, name='test'),
    url(r'^Analysis/productSentiment/', productSentiment, name='productSentiment'),
    url(r'^Analysis/userlevel/', getlevel, name='getlevel'),
    url(r'^Analysis/color/', colored, name='colored'),
    url(r'getprodutlist', getprodutlist, name=' getprodutlist'),
    url(r'getshopname', getshopname, name=' getshopname'),
    url(r'userorder',userorder,name='userorder'),
    url(r'^Analysis/', analysis, name='analysis'),

]
